package Scenes;

import Controllers.HideDataHomeController;
import javafx.scene.input.MouseEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * This class is responsible for setting up the JavaFX scene for 'HideDataHome'fxml and
 * setting up listeners for actions by the user.
 */
public class HideDataHomeScene {

    //declare the controller
    private HideDataHomeController myController;
    //declare stage
    private Stage myStage;

    public HideDataHomeScene(Stage stage){
        this.myStage = stage;
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getClassLoader().getResource("Interfaces\\'HideDataHome.fxml"));
        try {
            // Setting the root.
            Parent root = fxmlLoader.load() ;
            root.setId("root");
            Scene scene = new Scene(root);
            HideDataHomeController tempController = fxmlLoader.getController();
            setController(tempController);
            // Adding the listeners for the buttons on the scene.
            setUpButtons();
            myStage.setScene(scene);
            myStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setController(HideDataHomeController controller){
        this.myController = controller;
    }

    private void setUpButtons() {
        myController.getInImageButton().setOnMouseClicked(this::inAnImage);
        myController.getInTextButton().setOnMouseClicked(this::inText);
        myController.getBackButton().setOnMouseClicked(this::back);
    }

    private void inAnImage(MouseEvent e){
        new HDImageScene(myStage);
    }

    private void inText(MouseEvent e){
        new HDTextScene(myStage);
    }

    private void back(MouseEvent e){
        new MainHomeScene(myStage);
    }

}
