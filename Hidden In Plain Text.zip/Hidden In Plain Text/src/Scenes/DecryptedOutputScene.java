package Scenes;

import Controllers.DecryptedTextOutController;
import Controllers.EmbeddedTextOutController;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * This class is responsible for setting up the JavaFX scene for DecryptedTextOut.fxml and
 * setting up listeners for actions by the user.
 */
public class DecryptedOutputScene {

    private DecryptedTextOutController myController;
    private String message;
    private Stage myStage;

    public DecryptedOutputScene(Stage stage, String message) {
        this.myStage = stage;
        this.message = message;
        FXMLLoader fxmlLoader = new FXMLLoader(
                getClass().getClassLoader().getResource("Interfaces\\DecryptedTextOut.fxml"));
        try {
            // Setting the root.
            Parent root = fxmlLoader.load();
            root.setId("root");
            Scene scene = new Scene(root);
            DecryptedTextOutController tempController = fxmlLoader.getController();
            setController(tempController);
            // Adding the listeners for the buttons on the scene.
            setUpButtons();
            myStage.setScene(scene);
            myStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setController(DecryptedTextOutController controller){
        this.myController = controller;
    }

    private void setUpButtons() {
        myController.getCloseButton().setOnMouseClicked(this::close);
        myController.getBackButton().setOnMouseClicked(this::back);
        System.out.println(message);
        myController.setOutputBox(message);
    }

    private void back(MouseEvent e){
        new MainHomeScene(myStage);
    }

    private void close(MouseEvent e) { System.exit(0);}

    public DecryptedTextOutController getMyController(){
        return myController;
    }
}
