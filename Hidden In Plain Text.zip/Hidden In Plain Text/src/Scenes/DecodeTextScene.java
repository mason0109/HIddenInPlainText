package Scenes;

import Controllers.DecodeTextController;
import Controllers.DecryptedTextOutController;
import Controllers.MainHomePageController;
import DialogBoxes.DialogBox;
import EmbeddingTechniques.ForText.LineShift;
import EmbeddingTechniques.ForText.WordShift;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import javax.sound.sampled.Line;

/**
 * This class is responsible for setting up the JavaFX scene for 'DecodeText'page.fxml and
 * setting up listeners for actions by the user.
 */
public class DecodeTextScene {

    private DecodeTextController myController;
    private DecryptedTextOutController newController;
    private String decodingChoice;
    private Stage myStage;

    public DecodeTextScene(Stage stage) {
        this.myStage = stage;
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getClassLoader().getResource("Interfaces\\'DecodeText'page.fxml"));
        try {
            // Setting the root.
            Parent root = fxmlLoader.load();
            root.setId("root");
            Scene scene = new Scene(root);
            DecodeTextController tempController = fxmlLoader.getController();
            setController(tempController);
            // Adding the listeners for the buttons on the scene.
            setUpButtons();
            myStage.setScene(scene);
            myStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setController(DecodeTextController controller) {
        this.myController = controller;
    }

    private void setUpButtons() {
        myController.getDecodeButton().setOnMouseClicked(this::decodeText);
        myController.setDecodeChoiceBox("Word Shift Decoding", "Line Shift Decoding");
        myController.getBackButton().setOnMouseClicked(this::back);
        myController.getDecodeChoiceBox().setOnAction(event ->
                selection(myController.getDecodeChoiceBox().getValue().toString()));
    }

    /**
     * Embedding choices selected based on SelectionBox choice.
     * @param choice - SelectionBox choice as String.
     */
    private void selection(String choice) {
        switch (choice) {
            case "Word Shift Decoding":
                decodingChoice = "Word Shift Decoding";
                break;
            case "Line Shift Decoding":
                decodingChoice = "Line Shift Decoding";
                break;
            default:
                break;
        }
    }

    private void back(MouseEvent e) {
        new MainHomeScene(myStage);
    }

    /**
     * Check the validity of the message found.
     * @param message - message found.
     * @return - true is the message is valid, false otherwise.
     */
    private boolean messageIsReal(String message){
        boolean valid = true;
        for (char c : message.toCharArray()){
            if (!Character.isLetter(c) && !Character.isDigit(c)){
                valid = false;
            }
        }
        return valid;
    }

    /**
     * If start is clicked by the user, all inputs are checked and
     * selected decoding technique is run on the inputted text.
     * @param e - MouseEvent
     */
    private void decodeText(MouseEvent e) {
        String textToDecode = myController.getTextToDecodeBox().getText();
        if (textToDecode != null && !textToDecode.equals("")) {
            String decodedText = "";
            if (decodingChoice != null && !decodingChoice.equals("")) {
                if (decodingChoice == "Word Shift Decoding") {
                    WordShift wordShift = new WordShift();
                    decodedText = wordShift.decodeMessage(textToDecode);
                    if (decodedText != null && !decodedText.equals("")){
                        if (messageIsReal(decodedText)){
                            new DecryptedOutputScene(myStage, decodedText);
                        } else {
                            DialogBox.boxInfo("Sorry! Looks like there's no message here.", "No message found");
                        }
                    } else {
                        DialogBox.boxInfo("Sorry! Looks like there's no message here.", "No message found");
                    }
                } else if (decodingChoice == "Line Shift Decoding") {
                    LineShift lineShift = new LineShift();
                    decodedText = lineShift.decodeMessage(textToDecode);
                    if (decodedText != null && !decodedText.equals("")){
                        if (messageIsReal(decodedText)){
                            new DecryptedOutputScene(myStage, decodedText);
                        } else {
                            DialogBox.boxInfo("Sorry! Looks like there's no message here.", "No message found");
                        }
                    } else {
                        DialogBox.boxInfo("Sorry! Looks like there's no message here.", "No message found");
                    }

                }
            } else {
                DialogBox.boxInfo("Please make sure to select a decoding technique.", "PLease select a technique.");
            }
        } else {
            DialogBox.boxInfo("Enter the text you'd like to decode.", "PLease enter the text.");
        }

    }

}
