package Scenes;

import Controllers.MainHomePageController;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * This class is responsible for setting up the JavaFX scene for 'MainHomePage'fxml and
 * setting up listeners for actions by the user.
 */
public class MainHomeScene {

    //declare the controller
    private MainHomePageController myController;
    //declare stage
    private Stage myStage;

    public MainHomeScene(Stage stage){
        this.myStage = stage;
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getClassLoader().getResource("Interfaces\\MainHomePage.fxml"));
        try {
            // Setting the root.
            Parent root = fxmlLoader.load();
            root.setId("root");
            Scene scene = new Scene(root);
            MainHomePageController tempController = fxmlLoader.getController();
            setController(tempController);
            // Adding the listeners for the buttons on the scene.
            setUpButtons();
            myStage.setScene(scene);
            myStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setController(MainHomePageController controller){
        this.myController = controller;
    }

    private void setUpButtons() {
        myController.getHideOwnButton().setOnMouseClicked(this::hideOwnData);
        myController.getDetectButton().setOnMouseClicked(this::detectData);
        myController.getExit().setOnMouseClicked(this::exit);
        myController.getDecodeTextButton().setOnMouseClicked(this::decodeText);
        myController.getDecodeImageButton().setOnMouseClicked(this::decodeImage);
    }

    private void hideOwnData(MouseEvent e) {
        new HideDataHomeScene(myStage);
    }

    private void detectData(MouseEvent e) {
        new DDHomeScene(myStage);
    }

    private void exit(MouseEvent e){
        myStage.close();
    }

    private void decodeText(MouseEvent e) { new DecodeTextScene(myStage); }

    private void decodeImage(MouseEvent e) { new DecodeImageScene(myStage); }

}
