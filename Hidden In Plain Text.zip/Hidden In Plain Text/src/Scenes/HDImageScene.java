package Scenes;

import Controllers.HideDataImageController;
import DialogBoxes.DialogBox;
import EmbeddingTechniques.ForImages.LSB;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

/**
 * This class is responsible for setting up the JavaFX scene for 'HidingDataImage'fxml and
 * setting up listeners for actions by the user.
 */
public class HDImageScene {
    private HideDataImageController myController;
    private BufferedImage coverImage = null;
    private String embeddingChoice;
    private String messageToHide;
    private Stage myStage;

    public HDImageScene(Stage stage) {
        this.myStage = stage;
        FXMLLoader fxmlLoader = new FXMLLoader(
                getClass().getClassLoader().getResource("Interfaces\\'HidingDataImage'page.fxml"));
        try {
            // Setting the root.
            Parent root = fxmlLoader.load();
            root.setId("root");
            Scene scene = new Scene(root);
            HideDataImageController tempController = fxmlLoader.getController();
            setController(tempController);
            // Adding the listeners for the buttons on the scene.
            setUpButtons();
            myStage.setScene(scene);
            myStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setController(HideDataImageController controller){
        this.myController = controller;
    }

    private void setUpButtons() {
        myController.getBrowseButton().setOnMouseClicked(this::browseFiles);
        myController.getBackButton().setOnMouseClicked(this::back);
        myController.getStartButton().setOnMouseClicked(this::start);
        //add values to the selection box
        myController.setSelectionBox("Least Significant Bit Encoding");
        //myController.setSelectionBox("Discrete Cosine Transform Encoding");
        myController.getSelectionBox().setOnAction(event ->
                selection(myController.getSelectionBox().getValue().toString()));
    }

    /**
     * If user selects browse button on the interface, load and display a
     * file chooser.
     * @param e - Mouse Event onclicked.
     */
    private void browseFiles(MouseEvent m) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open Resource File");
        File selectedImage = fileChooser.showOpenDialog(myStage);
        if (selectedImage == null){
            return;
        }
        try {
            FileInputStream imageStream = new FileInputStream(selectedImage);
            coverImage = ImageIO.read(imageStream);
            if (coverImage != null){
                System.out.println("Image Selected.");
                myController.setImageFileBox(selectedImage.getName());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * Embedding choice determined based on selection box choice.
     * @param choice - selection choice as string.
     */
    private void selection(String choice){
        switch(choice){
            case "Least Significant Bit Encoding":
                embeddingChoice = "Least Significant Bit Encoding";
                break;
//            case "Discrete Cosine Transform Encoding":
//                embeddingChoice = "Discrete Cosine Transformation";
//                break;
            default:
                break;
        }
    }

    private void back(MouseEvent m){
        new HideDataHomeScene(myStage);
    }

    /**
     * If start is clicked by the user, all inputs are checked and
     * selected encoding technique carried out on the image.
     * @param e - MouseEvent
     */
    private void start(MouseEvent m){
        if (myController.getMessageTextField().getLength() == 0) {
            DialogBox.boxInfo("Enter the text you want to hide.", "Please enter text.");
        }
        if (coverImage == null){
            DialogBox.boxInfo("Please select the photo you wish to use.", "Please select a photo.");
        } else {
            messageToHide = myController.getMessageTextField().getText();
            if (embeddingChoice != null){
//                if (embeddingChoice == "Discrete Cosine Transformation"){
//                    DCT dct = new DCT(messageToHide, coverImage, myController);
//                    if (dct.getStatus()){
//                        new MainHomeScene(myStage);
//                    }
//                } else
                if (embeddingChoice == "Least Significant Bit Encoding"){
                    LSB lsb = new LSB(messageToHide, coverImage, myController);
                    if (lsb.getStatus()){
                        new MainHomeScene(myStage);
                    }
                }
            } else {
                DialogBox.boxInfo("Please select the embedding technique you'd like to use.", "Please select a technique.");
            }
        }

    }
}
