package Scenes;

import Controllers.DetectionOutputTextController;
import Detection.DetectionResults;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * This class is responsible for setting up the JavaFX scene for 'DetectionOutputText.fxml and
 * setting up listeners for actions by the user.
 */
public class DetectionOutputTextScene {
    DetectionOutputTextController myController;
    private String message;
    private Stage myStage;

    public DetectionOutputTextScene(Stage stage, String foundMessage, DetectionResults results){
        this.myStage = stage;
        this.message = foundMessage;
        FXMLLoader fxmlLoader = new FXMLLoader(
                getClass().getClassLoader().getResource("Interfaces\\DetectionOutputText.fxml"));
        try {
            // Setting the root.
            Parent root = fxmlLoader.load();
            root.setId("root");
            Scene scene = new Scene(root);
            DetectionOutputTextController tempController = fxmlLoader.getController();
            setController(tempController);
            // Adding the listeners for the buttons on the scene.
            setUpButtons(results);
            myStage.setScene(scene);
            myStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setController(DetectionOutputTextController controller){
        this.myController = controller;
    }

    private void setUpButtons(DetectionResults results) {
        myController.getBackButton().setOnMouseClicked(this::back);
        //set values on the results table based on the result's values.
        if (results.getTechniqueName() == "Line Shift Encoding"){
            myController.getLineShiftOutcomeLabel().setText(results.getTechniqueFound());
            myController.getWordShiftOutcomeLabel().setText("False");
            myController.setOutputBox(message);
        } else if (results.getTechniqueName() == "Word Shift Encoding"){
            myController.getWordShiftOutcomeLabel().setText(results.getTechniqueFound());
            myController.getLineShiftOutcomeLabel().setText("False");
            myController.setOutputBox(message);
        } else {
            myController.getLineShiftOutcomeLabel().setText("False");
            myController.getWordShiftOutcomeLabel().setText("False");
        }
    }

    private void back(MouseEvent e){
        new DDHomeScene(myStage);
    }
}
