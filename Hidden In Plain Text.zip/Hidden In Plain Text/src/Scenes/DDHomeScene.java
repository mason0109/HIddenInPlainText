package Scenes;

import Controllers.DDHomeController;
import Controllers.HideDataHomeController;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * This class is responsible for setting up the JavaFX scene for 'DetectData'home.fxml and
 * setting up listeners for actions by the user.
 */
public class DDHomeScene {

    //controller
    private DDHomeController myController;
    private Stage myStage;

    public DDHomeScene(Stage stage){
        this.myStage = stage;
        FXMLLoader fxmlLoader = new FXMLLoader(
                getClass().getClassLoader().getResource("Interfaces\\'DetectData'home.fxml"));
        try {
            // Setting the root.
            Parent root = fxmlLoader.load();
            root.setId("root");
            Scene scene = new Scene(root);
            DDHomeController tempController = fxmlLoader.getController();
            setController(tempController);
            // Adding the listeners for the buttons on the scene.
            setUpButtons();
            myStage.setScene(scene);
            myStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setController(DDHomeController controller){
        this.myController = controller;
    }

    private void setUpButtons() {
        myController.getImageOptionButton().setOnMouseClicked(this::inAnImage);
        myController.getTextOptionButton().setOnMouseClicked(this::inText);
        myController.getBackButton().setOnMouseClicked(this::back);
    }

    private void inAnImage(MouseEvent e){
        new DDImageScene(myStage);
    }

    private void inText(MouseEvent e){
        new DDTextScene(myStage);
    }

    private void back(MouseEvent e){
        new MainHomeScene(myStage);
    }
}
