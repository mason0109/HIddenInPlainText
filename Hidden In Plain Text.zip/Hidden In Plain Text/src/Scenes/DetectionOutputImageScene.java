package Scenes;

import Controllers.DetectionOutputImageController;
import Detection.DetectionResults;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * This class is responsible for setting up the JavaFX scene for DetectionOutputImage.fxml and
 * setting up listeners for actions by the user.
 */
public class DetectionOutputImageScene {

    DetectionOutputImageController myController;
    private String message;
    private Stage myStage;

    public DetectionOutputImageScene(Stage stage, String foundMessage, DetectionResults results){
        this.myStage = stage;
        this.message = foundMessage;
        FXMLLoader fxmlLoader = new FXMLLoader(
                getClass().getClassLoader().getResource("Interfaces\\DetectionOutputImage.fxml"));
        try {
            // Setting the root.
            Parent root = fxmlLoader.load();
            root.setId("root");
            Scene scene = new Scene(root);
            DetectionOutputImageController tempController = fxmlLoader.getController();
            setController(tempController);
            // Adding the listeners for the buttons on the scene.
            setUpButtons(results);
            myStage.setScene(scene);
            myStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setController(DetectionOutputImageController controller){
        this.myController = controller;
    }

    private void setUpButtons(DetectionResults results) {
        myController.getBackButton().setOnMouseClicked(this::back);
        //Sets values on the results table based on the values in 'results'
        if (results.getTechniqueName() == "Least Significant Bit Encoding") {
            myController.getLsbOutcomeLabel().setText(results.getTechniqueFound());
            myController.getDctOutcomeLabel().setText("N/A");
            myController.setOutputBox(message);
        } else {
            myController.getLsbOutcomeLabel().setText("False");
            myController.getDctOutcomeLabel().setText("N/A");
        }
//        } else if (results.getTechniqueName() == "Discrete Cosine Transform Encoding"){
//            myController.getDctOutcomeLabel().setText(results.getTechniqueFound());
//            myController.getLsbOutcomeLabel().setText("False");
//            myController.setOutputBox(message);
//        }

    }

    private void back(MouseEvent e){
        new DDHomeScene(myStage);
    }

}
