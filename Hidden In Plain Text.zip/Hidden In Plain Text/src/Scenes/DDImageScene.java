package Scenes;

import Controllers.DDImageController;
import Detection.DetectionResults;
import DialogBoxes.DialogBox;
import EmbeddingTechniques.ForImages.DCT;
import EmbeddingTechniques.ForImages.LSB;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

/**
 * This class is responsible for setting up the JavaFX scene for 'DetectDataInImage'page.fxml and
 * setting up listeners for actions by the user.
 */
public class DDImageScene {

    private DDImageController myController;
    private DetectionResults resultsLSB;
    private DetectionResults resultsDCT;
    private DetectionResults defaultNothingFound = new
            DetectionResults("Default", "False");
    private BufferedImage uploadedImage;
    private boolean lsbFound = false;
    private boolean dctFound = false;
    private Stage myStage;

    public DDImageScene(Stage stage) {
        this.myStage = stage;
        FXMLLoader fxmlLoader = new FXMLLoader(
                getClass().getClassLoader().getResource("Interfaces\\'DetectDataInImage'page.fxml"));
        try {
            // Setting the root.
            Parent root = fxmlLoader.load();
            root.setId("root");
            Scene scene = new Scene(root);
            DDImageController tempController = fxmlLoader.getController();
            setController(tempController);
            // Adding the listeners for the buttons on the scene.
            setUpButtons();
            myStage.setScene(scene);
            myStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setController(DDImageController controller) {
        this.myController = controller;
    }

    private void setUpButtons() {
        myController.getBrowseButton().setOnMouseClicked(this::browseForFile);
        myController.getBackButton().setOnMouseClicked(this::back);
        myController.getStartButton().setOnMouseClicked(this::start);
    }

    /**
     * If user selects browse button on the interface, load and display a
     * file chooser.
     * @param e - Mouse Event onclicked.
     */
    private void browseForFile(MouseEvent e) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open Resource File");
        File selectedImage = fileChooser.showOpenDialog(myStage);
        if (selectedImage == null){
            return;
        }
        try {
            FileInputStream imageStream = new FileInputStream(selectedImage);
            uploadedImage = ImageIO.read(imageStream);
            if (uploadedImage != null) {
                System.out.println("Image Selected.");
                myController.setFileNameTextbox(selectedImage.getName());
            }
        } catch (Exception er) {
            er.printStackTrace();
        }
    }

    private void back(MouseEvent e) {
        new DDHomeScene(myStage);
    }

    /**
     * Check the validity of the message found.
     * @param message - message found.
     * @return - true is the message is valid, false otherwise.
     */
    private boolean messageIsReal(String message){
        boolean valid = true;
        for (char c : message.toCharArray()){
            if (!Character.isLetter(c) && !Character.isDigit(c)){
                valid = false;
            }
        }
        return valid;
    }

    /**
     * If Start is clicked by the user, all inputs are checked and
     * detection routine is carried out.
     * @param e - MouseEvent
     */
    private void start(MouseEvent e) {
        //check image is valid
        if (uploadedImage != null) {
            //run lsb on the image
            LSB lsbTest = new LSB();
            String foundData = "";
            try {
                foundData = lsbTest.decodeImage(uploadedImage);
            } catch (Exception er) {
                System.out.println("Some sxception; DDImageScene l81");
            }
            if (foundData != null && !foundData.equals("")) {
                if (messageIsReal(foundData)) {
                    lsbFound = true;
                }
            }
            String result;
            if (lsbFound) {
                result = "True";
            } else {
                result = "False";
            }
            resultsLSB = new DetectionResults("Least Significant Bit Encoding", result);

//check for dct - the following code is functional, but dct itself isn't.
//            DCT dctTest = new DCT();
//            String foundData2 = "";
//            foundData2 = dctTest.decodeImage(uploadedImage);
//            if (foundData2 != null && !foundData2.equals("")) {
//                dctFound = true;
//            }
//            String result2;
//            if (dctFound) {
//                result2 = "True";
//            } else {
//                result2 = "False";
//            }
//            resultsDCT = new DetectionResults("Discrete Cosine Transform Encoding", result2);

            if (result.equals("True")) {
                new DetectionOutputImageScene(myStage, foundData, resultsLSB);

            //if (result2.equals("True")) {
            //    new DetectionOutputImageScene(myStage, foundData2, resultsDCT);

            } else {
                new DetectionOutputImageScene(myStage, "", defaultNothingFound);
                System.out.println("No techniques found");
            }
        } else {
            DialogBox.boxInfo("Please select the image you wish to scan.",
                    "Please select an image.");
        }
    }
}
