package Scenes;

import Controllers.HideDataTextController;
import DialogBoxes.DialogBox;
import EmbeddingTechniques.ForText.LineShift;
import EmbeddingTechniques.ForText.WordShift;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * This class is responsible for setting up the JavaFX scene for 'HidingDataInText'fxml and
 * setting up listeners for actions by the user.
 */
public class HDTextScene {
    private HideDataTextController myController;
    private String embeddingChoice;
    private String messageToHide;
    private String coverMessage;
    private Stage myStage;

    public HDTextScene(Stage stage){
        this.myStage = stage;
        FXMLLoader fxmlLoader = new FXMLLoader(
                getClass().getClassLoader().getResource("Interfaces\\'HidingDataInText'page.fxml"));
        try {
            // Setting the root.
            Parent root = fxmlLoader.load();
            root.setId("root");
            Scene scene = new Scene(root);
            HideDataTextController tempController = fxmlLoader.getController();
            setController(tempController);
            // Adding the listeners for the buttons on the scene.
            setUpButtons();
            myStage.setScene(scene);
            myStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setController(HideDataTextController controller){
        this.myController = controller;
    }

    private void setUpButtons() {
        myController.getBackButton().setOnMouseClicked(this::back);
        myController.getStartButton().setOnMouseClicked(this::start);
        myController.setSelectionBox("Word Shift Encoding","Line Shift Encoding");
        myController.getSelectionBox().setOnAction(event ->
                selection(myController.getSelectionBox().getValue().toString()));
    }

    /**
     * Embedding choice determined based on selection box choice.
     * @param choice - selection choice as string.
     */
    private void selection(String choice){
        switch(choice){
            case "Word Shift Encoding":
                embeddingChoice = "Word Shift Encoding";
                break;
            case "Line Shift Encoding":
                embeddingChoice = "Line Shift Encoding";
                break;
            default:
                break;
        }
    }

    private void back(MouseEvent e){
        new HideDataHomeScene(myStage);
    }

    /**
     * If start is clicked by the user, all inputs are checked and
     * selected encoding technique carried out on the block of text.
     * @param e - MouseEvent
     */
    private void start(MouseEvent e){
        //checking secret message
        if (myController.getMessageTextField().getLength() == 0){
            DialogBox.boxInfo("Enter the message you want to hide.",
                    "Please enter a message.");
        } else {
            messageToHide = myController.getMessageTextField().getText();
        }
        coverMessage = myController.getCoverTextField().getText();
        if (embeddingChoice != null && !embeddingChoice.equals("")){
            if (embeddingChoice == "Word Shift Encoding") {
                new WordShift(messageToHide, coverMessage, myStage);

            } else if (embeddingChoice == "Line Shift Encoding"){
                new LineShift(messageToHide, coverMessage, myStage);
            }
        } else {
            DialogBox.boxInfo("Please select the embedding technique you'd like to use.",
                    "Please select a technique.");
        }
    }
}
