package Scenes;

import Controllers.DecodeImageController;
import Controllers.MainHomePageController;
import DialogBoxes.DialogBox;
import EmbeddingTechniques.ForImages.DCT;
import EmbeddingTechniques.ForImages.LSB;
import com.sun.xml.internal.ws.policy.privateutil.PolicyUtils;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
/**
 * This class is responsible for setting up the JavaFX scene for ''DecodeImage'page.fxml and
 * setting up listeners for actions by the user.
 */
public class DecodeImageScene {

    private DecodeImageController myController;
    private BufferedImage encryptedImage = null;
    private String embeddingChoice;
    private Stage myStage;

    public DecodeImageScene(Stage stage){
        myStage = stage;
        FXMLLoader fxmlLoader = new FXMLLoader();
        fxmlLoader.setLocation(getClass().getClassLoader().getResource("Interfaces\\'DecodeImage'page.fxml"));
        try {
            // Setting the root.
            Parent root = fxmlLoader.load();
            root.setId("root");
            Scene scene = new Scene(root);
            DecodeImageController tempController = fxmlLoader.getController();
            setController(tempController);
            // Adding the listeners for the buttons on the scene.
            setUpButtons();
            myStage.setScene(scene);
            myStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setController(DecodeImageController controller){
        this.myController = controller;
    }

    private void setUpButtons() {
        myController.getBrowseButton().setOnMouseClicked(this::browse);
        myController.getDecodeButton().setOnMouseClicked(this::decodeImage);
        myController.getBackButton().setOnMouseClicked(this::back);
        myController.setSelectionBox("Least Significant Bit");
        myController.getSelectionBox().setOnAction(event ->
                selection(myController.getSelectionBox().getValue().toString()));
    }

    /**
     * If user selects browse button on the interface, load and display a
     * file chooser.
     * @param e - Mouse Event onclicked.
     */
    private void browse(MouseEvent e){
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open Resource File");
        File selectedImage = fileChooser.showOpenDialog(myStage);
        if (selectedImage == null){
            return;
        }
        try {
            FileInputStream imageStream = new FileInputStream(selectedImage);
            encryptedImage = ImageIO.read(imageStream);
            if (encryptedImage != null){
                System.out.println("Image Selected.");
                myController.setImageFileBox(selectedImage.getName());
            }
        } catch (NullPointerException error1) {
            error1.printStackTrace();
        } catch (FileNotFoundException error2) {
            error2.printStackTrace();
        } catch (IOException error3) {
            error3.printStackTrace();
        }
    }

    /**
     * Embedding choice determined based on selection box choice.
     * @param choice - selection choice as string.
     */
    private void selection(String choice){
        switch(choice){
            case "Least Significant Bit":
                embeddingChoice = "Least Significant Bit";
                break;
//            case "Discrete Cosine Transformation":
//                embeddingChoice = "Discrete Cosine Transformation";
//                break;
            default:
                break;
        }
    }

    private void back(MouseEvent e){
        new MainHomeScene(myStage);
    }

    /**
     * Check the validity of the message found.
     * @param message - message found.
     * @return - true is the message is valid, false otherwise.
     */
    private boolean messageIsReal(String message){
        boolean valid = true;
        for (char c : message.toCharArray()){
            if (!Character.isLetter(c) && !Character.isDigit(c)){
                valid = false;
            }
        }
        return valid;
    }

    /**
     * If start is clicked by the user, all inputs are checked and
     * selected decoding technique is run on the uploaded image.
     * @param e - MouseEvent
     */
    private void decodeImage(MouseEvent e) {
        if (encryptedImage != null) {
            if (embeddingChoice != null && !embeddingChoice.equals("")) {
//            if (embeddingChoice == "Discrete Cosine Transformation"){
//                DCT dct = new DCT();
//                //dct.decodeImage();
//                if (dct.getStatus()){
//                    new MainHomeScene(myStage);
//                }
//            } else
                if (embeddingChoice == "Least Significant Bit") {
                    LSB lsb = new LSB();
                    try {
                        String foundMessage = lsb.decodeImage(encryptedImage);
                        if (foundMessage != null && foundMessage != "") {
                            if (messageIsReal(foundMessage)) {
                                if (lsb.getStatus()) {
                                    new DecryptedOutputScene(myStage, foundMessage);
                                }
                            } else {
                                DialogBox.boxInfo("Sorry! Looks like there's no message here.", "No message found");
                            }
                        } else {
                            DialogBox.boxInfo("Sorry! Looks like there's no message here.", "No message found");
                        }
                    } catch (Exception er) {
                        System.out.println("ahhhhhh");
                    }
                }
            } else {
                DialogBox.boxInfo("Please select the decoding technique you'd like you use.",
                        "Please select a technique");
            }
        }



    }
}
