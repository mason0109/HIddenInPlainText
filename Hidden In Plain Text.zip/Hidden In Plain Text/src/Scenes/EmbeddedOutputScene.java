package Scenes;

import Controllers.EmbeddedTextOutController;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * This class is responsible for setting up the JavaFX scene for EmbeddedTextOut.fxml and
 * setting up listeners for actions by the user.
 */
public class EmbeddedOutputScene {

    private EmbeddedTextOutController myController;
    private Stage myStage;

    public EmbeddedOutputScene(Stage stage) {
        this.myStage = stage;
        FXMLLoader fxmlLoader = new FXMLLoader(
                getClass().getClassLoader().getResource("Interfaces\\EmbeddedTextOut.fxml"));
        try {
            // Setting the root.
            Parent root = fxmlLoader.load();
            root.setId("root");
            Scene scene = new Scene(root);
            EmbeddedTextOutController tempController = fxmlLoader.getController();
            setController(tempController);
            // Adding the listeners for the buttons on the scene.
            setUpButtons();
            myStage.setScene(scene);
            myStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setController(EmbeddedTextOutController controller){
        this.myController = controller;
    }

    private void setUpButtons() {
        myController.getCloseButton().setOnMouseClicked(this::close);
        myController.getBackButton().setOnMouseClicked(this::back);
    }

    private void back(MouseEvent e){
        new MainHomeScene(myStage);
    }

    private void close(MouseEvent e) { System.exit(0);}

    public EmbeddedTextOutController getMyController(){
        return myController;
    }
}
