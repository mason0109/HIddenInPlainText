package Scenes;

import Controllers.DDTextController;
import Detection.DetectionResults;
import DialogBoxes.DialogBox;
import EmbeddingTechniques.ForText.LineShift;
import EmbeddingTechniques.ForText.WordShift;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * This class is responsible for setting up the JavaFX scene for 'DetectDataInText'page.fxml and
 * setting up listeners for actions by the user.
 */
public class DDTextScene {

    private DDTextController myController;
    private DetectionResults resultsLineShift;
    private DetectionResults resultsWordShift;
    private DetectionResults defaultNothingFound = new
            DetectionResults("Default", "False");
    private String encryptedMessage;
    private boolean lineShiftFound = false;
    private boolean wordShiftFound = false;
    private Stage myStage;

    public DDTextScene(Stage stage) {
        this.myStage = stage;
        FXMLLoader fxmlLoader = new FXMLLoader(
                getClass().getClassLoader().getResource("Interfaces\\'DetectDataInText'page.fxml"));
        try {
            // Setting the root.
            Parent root = fxmlLoader.load();
            root.setId("root");
            Scene scene = new Scene(root);
            DDTextController tempController = fxmlLoader.getController();
            setController(tempController);
            // Adding the listeners for the buttons on the scene.
            setUpButtons();
            myStage.setScene(scene);
            myStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setController(DDTextController controller){
        this.myController = controller;
    }

    private void setUpButtons() {
        myController.getBackButton().setOnMouseClicked(this::back);
        myController.getStartButton().setOnMouseClicked(this::start);
    }

    private void back(MouseEvent e){
        new DDHomeScene(myStage);
    }

    /**
     * If Start is clicked by the user, all inputs are checked and
     * detection routine is carried out.
     * @param e - MouseEvent
     */
    private void start(MouseEvent e){
        encryptedMessage = myController.getUserTextField().getText();
        if (encryptedMessage != null && !encryptedMessage.equals("")){
            //check for line shift
            LineShift lineShift = new LineShift();
            String lineShiftMessage = lineShift.decodeMessage(encryptedMessage);

            if (lineShiftMessage != null && !lineShiftMessage.equals("")){
                lineShiftFound = true;
            }
            String lineShiftResult;
            if (lineShiftFound){
                lineShiftResult = "True";
            } else {
                lineShiftResult = "False";
            }
            resultsLineShift = new DetectionResults("Line Shift Encoding", lineShiftResult);

            //check for word shift
            WordShift wordShift = new WordShift();
            String wordShiftMessage = wordShift.decodeMessage(encryptedMessage);

            if(wordShiftMessage != null && !wordShiftMessage.equals("")){
                wordShiftFound = true;
            }
            String wordShiftResult;
            if (wordShiftFound){
                wordShiftResult = "True";
            } else {
                wordShiftResult = "False";
            }
            resultsWordShift = new DetectionResults("Word Shift Encoding", wordShiftResult);

            if (lineShiftResult.equals("True")){
                new DetectionOutputTextScene(myStage, lineShiftMessage, resultsLineShift);
            } else if (wordShiftResult.equals("True")){
                new DetectionOutputTextScene(myStage, wordShiftMessage, resultsWordShift);
            } else {
                new DetectionOutputTextScene(myStage, "", defaultNothingFound);
            }
        } else {
            DialogBox.boxInfo("Enter the text you wish to scan.",
                    "Please enter the text.");
        }
    }
}


