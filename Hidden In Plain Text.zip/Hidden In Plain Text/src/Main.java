import Scenes.MainHomeScene;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class Main extends Application {
    /**
     * This method instantiates the MainHomeScene class.
     */
    @Override
    public void start(Stage primaryStage) throws Exception {
        MainHomeScene mainHomeStage = new MainHomeScene(primaryStage);
    }

    /**
     * This method starts the program.
     *
     * @param args
     *            These are the launch arguments of the program.
     */
    public static void main(String[] args) {
        launch(args);

    }
}

