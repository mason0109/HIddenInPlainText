package Detection;

import javafx.beans.property.SimpleStringProperty;

/**
 * This class represents the results of the system carrying out detection
 * on cover mediums.
 */
public class DetectionResults {
    private SimpleStringProperty techniqueName;
    private SimpleStringProperty techniqueFound;

    public DetectionResults(String techniqueName, String techniqueFound){
        this.techniqueName = new SimpleStringProperty(techniqueName);
        this.techniqueFound = new SimpleStringProperty(techniqueFound);
    }

    public String getTechniqueName(){
        return techniqueName.get();
    }

    public void setTechniqueName(String text){
        techniqueName = new SimpleStringProperty(text);
    }

    public String getTechniqueFound(){
        return techniqueFound.get();
    }

    public void setTechniqueFound(String result){
        techniqueFound = new SimpleStringProperty(result);
    }
}
