package DialogBoxes;
import javax.swing.*;
import javax.swing.text.BadLocationException;
import javax.swing.text.Document;
import javax.swing.text.SimpleAttributeSet;
import java.awt.*;

/**
 * This class represents a standard dialog box which is used
 * to alert the user.
 */
public class DialogBox {

    public DialogBox(){}

    public static void boxInfo(String errorMsg, String titlebar) {
        JTextPane jtp = new JTextPane();
        Document doc = jtp.getDocument();
        try {
            doc.insertString(doc.getLength(), errorMsg, new SimpleAttributeSet());
        } catch (BadLocationException err){
            err.printStackTrace();
        }
        jtp.setSize(new Dimension(480, 10));
        jtp.setPreferredSize(new Dimension(480, jtp.getPreferredSize().height));
        JOptionPane.showMessageDialog(null, jtp, "" +
                titlebar, JOptionPane.INFORMATION_MESSAGE);
    }

}
