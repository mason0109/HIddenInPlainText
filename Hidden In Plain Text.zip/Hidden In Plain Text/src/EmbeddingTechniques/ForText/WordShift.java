package EmbeddingTechniques.ForText;

import DialogBoxes.DialogBox;
import Scenes.EmbeddedOutputScene;
import com.sun.xml.internal.fastinfoset.util.CharArray;
import javafx.stage.Stage;

import java.io.ByteArrayOutputStream;
import java.lang.reflect.Array;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * This class is used to carry out Word Shift encoding and decoding on text.
 */
public class WordShift {
    private byte[] messageAsBytes = null;
    private String encryptedText = null;
    private Stage myStage;
    private int bytePos = 0;
    private int bitPos = 0;
    private boolean success = false;

    public WordShift(String messageToHide, String coverMessage, Stage stage){
        myStage = stage;

        if (checkCoverText(messageToHide, coverMessage)){
            messageAsBytes = messageToHide.getBytes();
            encryptedText = encryptMessage(coverMessage);

            if (encryptedText == null || encryptedText == messageToHide){
                success = false;
            } else {
                System.out.println("Your text has been hidden.");
                success = true;
                EmbeddedOutputScene outputScene = new EmbeddedOutputScene(myStage);
                outputScene.getMyController().setOutputBox(encryptedText);
            }
        } else {
            System.out.println("Your cover text is not big enough.");
            DialogBox.boxInfo("Invalid cover text", "Your cover text is not big enough.");
            success = false;
        }

    }

    public WordShift(){}

    /**
     * Encoding method:
     * for each character in the cover message, if the character is a white space and the
     * current bit is a 0 then add another space.
     * @param coverMessage - message to hide data in
     * @return - String: Embedded data.
     */
    private String encryptMessage(String coverMessage){
        String embeddedMessage = "";

        for (char c : coverMessage.toCharArray()){
            if (Character.isWhitespace(c)) {
                int bitValue = getNextBitEncoding();
                if (bitValue == 0){
                    embeddedMessage += c + " ";
                } else {
                    embeddedMessage += c; }
            } else {
                embeddedMessage += c;
            }
        }
        return embeddedMessage;
    }

    /**
     * This method keeps global track of the current bit being used,
     * and allows for getting the next one in sequence.
     * @return - a bit value
     */
    private int getNextBitEncoding(){
        int bit = 0;
        if (messageAsBytes != null) {
            byte b = messageAsBytes[bytePos];
            bit = (b >> 7 - bitPos) & 1;
            bitPos++;
        }

        if (bitPos > 7) {
            bytePos++;
            bitPos = 0;
            assert messageAsBytes != null;
            if (bytePos >= messageAsBytes.length) {
                bytePos = 0;
            }
        }
        return bit;
    }

    /**
     * Decoding method:
     * for each character in the encoded text, if the character is a white space,
     * check if there's another white space next, if yes then add 0 to the
     * retreived bits. Use constructBytes to convert this to a byte[] and
     * then convert to ASCII.
     * @param encodedText- text contianing the secret message.
     * @return - String: the secret message
     */
    public String decodeMessage(String encodedText){
        ArrayList<Integer> retreivedBits = new ArrayList<>();
        char[] chars = encodedText.toCharArray();
        for (int i=0; i<chars.length; i++){
            char c = chars[i];
            if (Character.isWhitespace(c)){
                int j = i;
                i = (i ==(chars.length - 1)) ? i : i+1;
                if (i != j) {
                    if(Character.isWhitespace(chars[i])){
                        retreivedBits.add(0);
                    } else {
                        retreivedBits.add(1);
                    }
                }
            }
        }

        byte[] decodedBytes = constructBytes(retreivedBits);
        String decodedText = new String(decodedBytes,StandardCharsets.UTF_8);
        return decodedText;
    }

    /**
     * THis method is used to construct bytes from an arraylist of intergers.
     * @param bits - retrieved bits from the text.
     * @return - The bits as a byte[]
     */
    private byte[] constructBytes(ArrayList<Integer> bits){
        int numBytes = bits.size()/8;
        byte[] out = new byte[numBytes];
        int mask;

        for(int i=0; i < numBytes; i++){
            mask = 0;
            for(int j=0; j<8; j++){
                int pos = (i * 8) + j;
                mask = mask | bits.get(pos);
                if(j != 7) {
                    mask = mask << 1;
                }
            }
            out[i] = (byte)mask;
        }
        return out;
    }

    private boolean checkCoverText(String messageToHide, String coverMessage) {
        int spaceCounterCover = 0;
        int charCounter = 0;
        int requiredSpaces = 0; //how many spaces the message needs to be hidden successfully

        char[] coverMessageChars = coverMessage.toCharArray();
        char[] messageChars = messageToHide.toCharArray();

        //how many spaces there are in the cover message:
        for (char c : coverMessageChars){
            if (Character.isWhitespace(c)){
                spaceCounterCover++;
            }
        }

        //how many chars are in the message to hide:
        for (char c : messageChars){
            if (c != '\n' && c != '\r'){
                charCounter++;
            }
        }

        requiredSpaces = charCounter*8;
        if (requiredSpaces > spaceCounterCover){
            return false;
        } else {
            return true;
        }
    }
}
