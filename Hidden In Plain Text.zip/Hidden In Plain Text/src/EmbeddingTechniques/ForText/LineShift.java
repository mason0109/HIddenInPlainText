package EmbeddingTechniques.ForText;

import DialogBoxes.DialogBox;
import Scenes.EmbeddedOutputScene;
import javafx.stage.Stage;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

/**
 * This class is used to carry out Line Shift encoding and decoding on text.
 */
public class LineShift {
    private byte[] messageAsBytes = null;
    private String encryptedText = "";
    private boolean success = false;
    private int bytePos = 0;
    private int bitPos = 0;
    private Stage myStage;

    public LineShift(String messageToHide, String coverMessage, Stage stage) {
        myStage = stage;

        if (checkCoverText(messageToHide, coverMessage)){
            messageAsBytes = messageToHide.getBytes();
            encryptedText = encryptMessage(coverMessage);

            if (encryptedText == null || encryptedText == messageToHide) {
                success = false;
            } else {
                System.out.println("Your text has been hidden.");
                success = true;
                EmbeddedOutputScene outputScene = new EmbeddedOutputScene(myStage);
                outputScene.getMyController().setOutputBox(encryptedText);
            }
        } else {
            System.out.println("Your cover text is not big enough.");
            DialogBox.boxInfo("Invalid cover text", "Your cover text is not big enough.");
            success = false;
        }
    }

    public LineShift() { }

    /**
     * Encoding method:
     * Goes through each character in the cover message, when a newline character
     * is found, if the current message bit is a 0 then add a new line, if not leave it.
     * @param coverMessage - The text to hide the data in.
     * @return - The embedded text.
     */
    private String encryptMessage(String coverMessage) {
        String message = "";
        for (char c : coverMessage.toCharArray()) {
            message += c;
            if (String.valueOf(c).matches("\n")) {
                int bitValue = getNextBit();
                if (bitValue == 0) { //0 = double space
                    message += "\n";
                } else if (bitValue == 1) {
                    message += "";
                }
            }

        }
        return message;
    }

    /**
     * This method keeps global track of the current bit being used,
     * and allows for getting the next one in sequence.
     * @return - a bit value.
     */
    private int getNextBit() {
        int bit = 0;
        if (messageAsBytes != null) {
            byte b = messageAsBytes[bytePos];
            bit = (b >> 7 - bitPos) & 1;
            bitPos++;
        }

        if (bitPos > 7) {
            bytePos++;
            bitPos = 0;
            if (bytePos >= messageAsBytes.length) {
                bytePos = 0;
            }
        }
        return bit;
    }

    /**
     * Decoding method:
     * Goes through each character in the text, if the character is a newline character
     * then check if there's another newline character. If there is add 0 to the arraylist.
     * Use construct bytes to make a byte[] of values, then convert to ASCII.
     * @param encryptedText - text to be decoded.
     * @return - the message retrieved from the text.
     */
    public String decodeMessage(String encryptedText) {
        ArrayList<Integer> retreivedBits = new ArrayList<>();
        char[] chars = encryptedText.toCharArray();

        for (int i = 0; i < chars.length; i++) {
            char c = chars[i];
            if (String.valueOf(c).matches("\n")) {
                int j = i;
                i = (i == (chars.length - 1)) ? i : i + 1;
                if (i != j) {
                    if (String.valueOf(chars[i]).matches("\n")) {
                        retreivedBits.add(0);
                    } else {
                        retreivedBits.add(1);
                    }
                }
            }
        }
        byte[] decodedBytes = constructBytes(retreivedBits);
        String decodedText = new String(decodedBytes, StandardCharsets.UTF_8);
        return decodedText;
    }

    /**
     * THis method is used to construct bytes from an arraylist of intergers.
     * @param bits - retrieved bits from the text
     * @return - The bits as a byte[]
     */
    private byte[] constructBytes(ArrayList<Integer> bits) {
        int numBytes = bits.size() / 8;
        byte[] out = new byte[numBytes];
        int mask;

        for (int i = 0; i < numBytes; i++) {
            mask = 0;
            for (int j = 0; j < 8; j++) {
                int pos = (i * 8) + j;
                mask = mask | bits.get(pos);
                if (j != 7) {
                    mask = mask << 1;
                }
            }
            out[i] = (byte) mask;
        }
        return out;
    }

    private boolean checkCoverText(String messageToHide, String coverMessage) {
        int lineCounter = 0;
        int charCounter = 0;
        int requiredLines = 0; //how many lines the message needs to be hidden successfully

        char[] coverMessageChars = coverMessage.toCharArray();
        char[] messageChars = messageToHide.toCharArray();

        //how many lines there are in the cover message:
        for (char c : coverMessageChars){
            if (c == '\n' || c == '\r'){
                lineCounter++;
            }
        }
        //how many chars are in the message to hide:
        for (char c : messageChars){
            if (c != '\n' && c != '\r'){
                charCounter++;
            }
        }
        requiredLines = charCounter*8;
        if (requiredLines > lineCounter){
            return false;
        } else {
            return true;
        }
    }
}
