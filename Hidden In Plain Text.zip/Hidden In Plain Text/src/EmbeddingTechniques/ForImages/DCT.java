package EmbeddingTechniques.ForImages;

import Controllers.HideDataImageController;
import DialogBoxes.DialogBox;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.charset.StandardCharsets;

/**
 * The following class is under construction.
 *
 * This class will allow for Discrete Cosine Transform to be carried
 * out as an embedding technique to hide data in images.
 * This will also include decoding of images.
 */

public class DCT {
    private BufferedImage encryptedImage = null;
    private byte[] messageBytes = null;
    private int side1 = 8;
    private int side2 = 8;
    private int imageHeight;
    private int imageWidth;
    private Boolean success;
    private LSB myLSB;
    private int N = 8;

    //first, for all dct related encoding, the same
    //quantisation table will be used (as for standard jpeg images).
    int quantTable[][] = { {16,12,14,14,18,24,49,72},
                       {11,12,13,17,22,35,64,92},
                       {10,14,16,22,37,55,78,95},
                       {16,19,24,29,56,94,87,98},
                       {24,26,40,51,68,81,103,112},
                       {40,58,57,87, 109,104,121,100},
                       {51,60,69,80,103,113,120,103},
                       {61,55,56,62,77,92,101,99}};

    //need a constructor here
    public DCT(String messageToHide, BufferedImage coverImage, HideDataImageController controller){
        messageBytes = getMessageBytes(messageToHide);
        encryptedImage = coverImage;
        imageHeight = coverImage.getHeight();
        imageWidth = coverImage.getWidth();
        myLSB = new LSB(messageBytes);

        //encode the image
        encryptedImage = encodeImage(coverImage);

        String filePath = "src\\Embedded Images\\" + controller.getImageFileBox() + "-embedded.png\\";
        File newImageFile = new File(filePath);
        try {
            ImageIO.write(coverImage, "png", newImageFile);
        } catch (Exception e){
            e.printStackTrace();
        }
        if (coverImage == null){
            System.out.println("Embedding failed");
            success = false;
        } else {
            System.out.println("The new image containing your data has been saved.");
            DialogBox.boxInfo("Embedding Complete!", "The new image has been saved.");
            success = true;
        }

    }

    public DCT(){}

    public byte[] getMessageBytes(String message) {
        return message.getBytes(StandardCharsets.US_ASCII);
    }

    private BufferedImage encodeImage(BufferedImage coverImage){
        Color imageColor = null;

        int[][] redValues = new int[imageHeight][imageWidth];
        int[][] greenValues = new int[imageHeight][imageWidth];
        int[][] blueValues = new int[imageHeight][imageWidth];

        for(int i=0; i<imageHeight; i++){
            for (int j=0; j<imageWidth; j++){
                imageColor = new Color(coverImage.getRGB(j, i));
                int redVal = imageColor.getRed();
                int greenVal = imageColor.getGreen();
                int blueVal = imageColor.getBlue();
                redValues[i][j] = redVal;
                greenValues[i][j] = greenVal;
                blueValues[i][j] = blueVal;
            }
        }

        int[][] encodedRedVals = startDCT(redValues);
        int[][] encodedGreenVals = startDCT(greenValues);
        int[][] encodedBlueVals = startDCT(blueValues);

        for(int i=0; i<imageWidth; i++){
            for (int j=0; j<imageHeight; j++) {
                int newRGB = (encodedRedVals[j][i]*65536)+(encodedGreenVals[j][i]*256)
                        +encodedBlueVals[j][i];
                encryptedImage.setRGB(i,j, newRGB);
            }
        }
        return encryptedImage;
    }

    private int[][] startDCT(int[][] colourArray) {
        int[][] updatedColArray = new int[colourArray.length][colourArray[0].length];
        int[][] _8by8chunk = new int[8][8];

        int numXChunks = imageWidth / 8;
        int numYChunks = imageHeight / 8;
        int totalChunks = numXChunks * numYChunks;

        int x = 0;
        int y = 0;
        int posX = 0;
        int posY = 0;

        for (int c = 0; c < totalChunks; c++) {
            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 8; j++) {
                    posX = (x * 8) + j;
                    posY = (y * 8) + i;
                    _8by8chunk[i][j] = colourArray[posY][posX];
                }
            }

            x++;
            y++;
            if (x >= numXChunks) {
                x = 0;
            }
            if (y >= numYChunks) {
                y = 0;
            }

            //pass through steps.
            //int[][] shiftedBlock = shiftDown(_8by8chunk); //pretty sure this makes it worse.
            double[][] dctMatrix = dctII(_8by8chunk);
            int[][] frequencyBlock = divideByQT(dctMatrix);
            //double[][] encodedBlock = myLSB.lsbOnBlock(frequencyBlock);
            int[][] stegDCTBlock = multiplyByQT(frequencyBlock);
            int[][] inversedDCTBlock = dctIII(stegDCTBlock);


            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 8; j++) {
                    posX = (x * 8) + j;
                    posY = (y * 8) + i;
                    updatedColArray[posY][posX] = inversedDCTBlock[i][j];
                }
            }
        }
        return updatedColArray;
    }

    //Step 1 - shift all values down by 127
    private int[][] shiftDown(int[][] shiftedBlock){
        int[][] shiftedValues = new int[8][8];
        for (int i=0; i<8; i++){
            for (int j=0; j<8; j++){
                int foundValue = shiftedBlock[i][j];
                shiftedValues[i][j] = (foundValue-127);
            }
        }
        return shiftedValues;
    }

    //Step 2 - DCT 2 EQUATION
    private double[][] dctII(int[][] matrix) {

        //this will hold the dct of the 8x8 matrix param
        double[][] dctOutput1 = new double[side1][side2];

        double ci, cj, dctTempVal, sum;

        for (int i=0;i<side1;i++){
            for (int j=0;j<side2;j++){
                //ci and cj depend on frequency, no. of rows
                //and no. of columns of the matrix param.
                //we use this to set a base case for them.
                if (i==0){
                    ci = 1 / Math.sqrt(side1);
                } else {
                    ci = Math.sqrt(2) / Math.sqrt(side1);
                }

                if (j==0){
                    cj = 1 / Math.sqrt(side2);
                } else {
                    cj = Math.sqrt(2) / Math.sqrt(side2);
                }

                sum = 0;
                for (int k=0;k<side1;k++){
                    for (int l=0;l<side2;l++){
                        dctTempVal = matrix[k][l] *
                                Math.cos((Math.PI / (side1)) * (k+0.5)*i) *
                                Math.cos((Math.PI / (side2)) * (l+0.5)*j);
                        sum = sum + dctTempVal;
                    }
                }
                dctOutput1[i][j] = (ci * cj * sum);
            }
        }
        return dctOutput1;
    }

    //Step 3 - Divide by Quant table
    private int[][] divideByQT(double[][] dctMatrix){
        int[][] frequencyTable = new int[8][8];

        for (int i=0; i<8; i++){
            for (int j=0; j<8; j++){
                double dctValue = dctMatrix[i][j];
                double qtValue = quantTable[i][j];
                frequencyTable[i][j] = (int) Math.round(dctValue / qtValue);
            }
        }
        return frequencyTable;
    }

    //(Reverting) Step 4 - multiply by Quant table
    private int[][] multiplyByQT(int[][] dctMatrix){
        int[][] frequencyTable = new int[8][8];

        for (int i=0; i<8; i++){
            for (int j=0; j<8; j++){
                int dctValue = dctMatrix[i][j];
                int qtValue = quantTable[i][j];
                frequencyTable[i][j] = Math.round(dctValue * qtValue);
            }
        }
        return frequencyTable;
    }

    //Step 5 - DCTIII Equation
    private int[][] dctIII(int[][] matrix){
        //define new output matrix.
        int[][] dctOutput2 = new int[side1][side2];
        double ck, cl, dctTempVal, sum;

        for (int i=0;i<side1;i++){
            for (int j=0;j<side2;j++){

                //sum will store the temporary sum of cosine signals.
                sum = 0;
                for (int k=0;k<side1;k++){
                    for (int l=0;l<side2;l++){

                        if (k==0){
                            ck = 1 / Math.sqrt(side1);
                        } else {
                            ck = Math.sqrt(2) / Math.sqrt(side1);
                        }

                        if (l==0){
                            cl = 1 / Math.sqrt(side2);
                        } else {
                            cl = Math.sqrt(2) / Math.sqrt(side2);
                        }

                        int currentVal = matrix[k][l];

                        dctTempVal = (currentVal / 2) +
                                Math.cos(((Math.PI / side1)* k) *(i + 0.5)) *
                                Math.cos(((Math.PI / side2)* l) *(j + 0.5));
                        sum += (ck * cl * dctTempVal);
                    }
                }
//                if (sum < 0){
//                    sum = 0;
//                } else if (sum > 255){
//                    sum = 255;
//                }
                dctOutput2[i][j] = (int)sum;
            }
        }
        return dctOutput2;
    }

    private int[][] multiplyBy2N(int[][] matrix){
        int[][] newMatrix = new int[side1][side2];

        for (int i=0; i<side1; i++){
            for (int j=0; j<side2; j++){
                int mVal = matrix[i][j];
                double newVal = mVal * (2/8);
                newMatrix[i][j] = (int)newVal*(2/8);
            }
        }

        return  newMatrix;
    }

    public boolean getStatus(){
        return success;
    }

    //Haven't written a decoder yet but for the sake of functionality
    //I will declare the method here.
    public String decodeImage(BufferedImage encodedImage){
        return "";
    }
}

