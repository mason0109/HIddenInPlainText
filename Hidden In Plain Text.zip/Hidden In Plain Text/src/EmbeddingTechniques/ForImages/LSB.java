package EmbeddingTechniques.ForImages;

import Controllers.HideDataImageController;
import DialogBoxes.DialogBox;
import Scenes.MainHomeScene;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Array;
import java.nio.Buffer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

/**
 * This class is used to carry out Least Significant Bit encoding and decoding
 * on images.
 */
public class LSB {
    private BufferedImage newImage = null;
    private byte[] messageBytes = null;
    private int imageHeight;
    private int imageWidth;
    private Boolean success;
    private int bytePos = 0;
    private int bitPos = 0;

    public LSB(String messageToHide, BufferedImage coverImage, HideDataImageController controller) {
        imageHeight = coverImage.getHeight();
        imageWidth = coverImage.getWidth();

        messageBytes = getMessageBytes(messageToHide);
        newImage = embedData(messageBytes, coverImage);

        String filePath = "src\\Embedded Images\\" + controller.getImageFileBox() + "-embedded.png\\";
        File newImageFile = new File(filePath);

        try {
            ImageIO.write(newImage, "png", newImageFile);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (newImage == null) {
            DialogBox.boxInfo("Embedding has failed.", "Try again.");
            success = false;
        } else {
            System.out.println("The new image containing your data has been saved.");
            DialogBox.boxInfo("Your new image has been saved.", "Embedding Complete!");
            success = true;
        }
    }

    //empty constructor (used for dct)
    public LSB(byte[] messageBytes) {
        this.messageBytes = messageBytes;
    }

    public LSB() {
        success = false;

    }

    private byte[] getMessageBytes(String message) {
        return message.getBytes(StandardCharsets.US_ASCII);
    }

    /**
     * Encoding Method:
     * For each pixel in the image, retrieve the Red, Green and Blue colour values.
     * Update each value's lsb with the current message bit (different bit for each value).
     * @param messageBytes - messgae to hide as a byte array.
     * @param coverImage - image to hide the data in.
     * @return - buffered image with hidden data.
     */
    private BufferedImage embedData(byte[] messageBytes, BufferedImage coverImage) {

        BufferedImage newImage = coverImage;
        Color imageColor = null;

        for (int x = 0; x < imageHeight; x++) {
            for (int y = 0; y < imageWidth; y++) {
                imageColor = new Color(coverImage.getRGB(y, x));
                int redVal = imageColor.getRed();
                int greenVal = imageColor.getGreen();
                int blueVal = imageColor.getBlue();
                String redb = Integer.toBinaryString(redVal);
                String greenb = Integer.toBinaryString(greenVal);
                String blueb = Integer.toBinaryString(blueVal);

                char newVal = (getNextBit() == 0)? '0' : '1';
                StringBuilder newStringr = new StringBuilder(redb);
                newStringr.setCharAt(redb.length()-1, newVal);
                String temp = newStringr.toString();
                int newRedVal = Integer.parseInt(temp, 2);

                newVal = (getNextBit() == 0)? '0' : '1';
                StringBuilder newStringg = new StringBuilder(greenb);
                newStringg.setCharAt(greenb.length()-1, newVal);
                temp = newStringg.toString();
                int newGreenVal = Integer.parseInt(temp, 2);

                newVal = (getNextBit() == 0)? '0' : '1';
                StringBuilder newStringb = new StringBuilder(blueb);
                newStringb.setCharAt(blueb.length()-1, newVal);
                temp = newStringb.toString();
                int newBlueVal = Integer.parseInt(temp, 2);

                int newRGB = (newRedVal * 65536) + (newGreenVal * 256) + newBlueVal;
                newImage.setRGB(y, x, newRGB);
            }
        }
        System.out.println("Your message is being embedded...");

        return newImage;
    }

    /**
     * Decoding Method:
     * for each pixel in the image, retrieve the Red, Green and Blue colour values.
     * Store the LSB from each colour value in an array. Convert the bit array into
     * bytes, which then convert to ASCII.
     * @param encryptedImage - image to retrieve data from.
     * @return - String: Decoded message from image.
     */
    public String decodeImage(BufferedImage encryptedImage) {
        ArrayList<Integer> retrievedBits = new ArrayList<>();
        imageWidth = encryptedImage.getWidth();
        imageHeight = encryptedImage.getHeight();
        String retrievedMessage = "";
        Color imageColor;

        for (int x = 0; x < imageHeight; x++) {
            for (int y = 0; y < imageWidth; y++) {
                imageColor = new Color(encryptedImage.getRGB(y, x));
                int redVal = imageColor.getRed();
                int greenVal = imageColor.getGreen();
                int blueVal = imageColor.getBlue();
                String redb = Integer.toBinaryString(redVal);
                String greenb = Integer.toBinaryString(greenVal);
                String blueb = Integer.toBinaryString(blueVal);

                char lsb1 = redb.charAt(redb.length() - 1);
                char lsb2 = greenb.charAt(greenb.length() - 1);
                char lsb3 = blueb.charAt(blueb.length() - 1);

                if (lsb1 == '1') {
                    retrievedBits.add(1);
                } else {
                    retrievedBits.add(0);
                }
                if (lsb2 == '1') {
                    retrievedBits.add(1);
                } else {
                    retrievedBits.add(0);
                }
                if (lsb3 == '1') {
                    retrievedBits.add(1);
                } else {
                    retrievedBits.add(0);
                }
            }
        }
        byte[] decodedBytes = constructBytes(retrievedBits);
        retrievedMessage = new String(decodedBytes, StandardCharsets.UTF_8);
        success = true;
        return retrievedMessage;
    }

    /**
     * THis method is used to construct bytes from an arraylist of intergers.
     * @param bits
     * @return
     */
    private byte[] constructBytes(ArrayList<Integer> bits) {
        int numBytes = bits.size() / 8;
        byte[] out = new byte[numBytes];
        int mask; //what we will use to construct the byte.

        for (int i = 0; i < numBytes; i++) {
            mask = 0;
            //loop 8 times for a new byte
            for (int j = 0; j < 8; j++) {
                //calculate the position of the next byte in the array
                int pos = (i * 8) + j;
                //we OR the new bit (pos) to the end of the
                //new byte. e.g.
                //    01101000
                // OR        1
                //  = 01101001
                mask = mask | bits.get(pos);

                if (j != 7) {
                    //shift the mask one space to the left.
                    mask = mask << 1;
                }
            }
            //add new byte to the out array
            out[i] = (byte) mask;
        }
        return out;
    }

    //DCT
    public double[][] lsbOnBlock(double[][] colourVals) {
        double[][] updatedValues = new double[colourVals.length][colourVals[0].length];

        for (int j = 0; j < 8; j++) {
            for (int l = 0; l < 8; l++) {
                if (j != 0 && l != 0) { //top corner
                    int colourValue = (int) colourVals[j][l];
                    if (colourValue != 1 && colourValue != 0) {
                        String colValBinary = Integer.toBinaryString(colourValue);

                        int currentBit = getNextBit();
                        String newColBinary = colValBinary.replace((char) (colValBinary.length() - 1), (char) currentBit);
                        int newColVal = Integer.parseUnsignedInt(newColBinary, 2);
                        updatedValues[j][l] = newColVal;
                    }
                }
            }
        }
        return updatedValues;
    }

    /**
     * This method keeps global track of the current bit being used,
     * and allows for getting the next one in sequence.
     * @return - a bit value
     */
    private int getNextBit() {
        int bit = 0;
        //if the msg isn't null
        if (messageBytes != null) {
            //set b to the byte at the current position
            byte b = messageBytes[bytePos]; //bytePos - class variable ^
            //bit shift right
            //bit - 7 to get the right bit position
            //then AND that value with 1 to extract
            bit = (b >> 7 - bitPos) & 1;
            bitPos++;
        }

        if (bitPos > 7) {
            bytePos++;  //increase bytePos
            bitPos = 0;  //reset pitPos
            if (bytePos >= messageBytes.length) {
                bytePos = 0;  //reset bytePos
            }
        }
        return bit;
    }

    public boolean getStatus() {
        return success;
    }
}

