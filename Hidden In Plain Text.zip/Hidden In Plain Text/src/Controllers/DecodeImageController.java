package Controllers;

import javafx.fxml.FXML;
import javafx.scene.control.*;

/**
 * This class acts as a Controller Class for 'DecodeIage'page.fxml and
 * DecodeImageScene.
 */

public class DecodeImageController {

    @FXML
    private TextField imageNameBox;
    @FXML
    private Button browseButton;
    @FXML
    private Button decodeButton;
    @FXML
    private Button backButton;
    @FXML
    private TextField decodedTextBox;
    @FXML
    private ChoiceBox selectionBox;

    public DecodeImageController(){}

    public void setImageFileBox(String text){
        this.imageNameBox.setText(text);
    }

    public void setBrowseButton(String text){
        this.browseButton.setText(text);
    }

    public void setDecodeButton(String text){
        this.decodeButton.setText(text);
    }

    public void setDecodedTextBox(String text){
        this.decodedTextBox.setText(text);
    }

    public void setBackButton(String text) { this.backButton.setText(text); }

    public TextField getImageNameBox(){
        return this.imageNameBox;
    }

    public Button getBrowseButton(){
        return this.browseButton;
    }

    public Button getDecodeButton(){
        return this.decodeButton;
    }

    public Button getBackButton() { return this.backButton; }

    public TextField getDecodedTextBox(){
        return this.decodedTextBox;
    }

    public void setSelectionBox(String text){
        this.selectionBox.getItems().addAll(text);
    }

    public ChoiceBox getSelectionBox(){
        return selectionBox;
    }

}
