package Controllers;

import javafx.fxml.FXML;
import javafx.scene.control.*;

/**
 * This class acts as a Controller Class for DetectionOutputImage.fxml and
 * DetectionOutputImageScene.
 */

public class DetectionOutputImageController {

    @FXML
    private Label mainLabel;
    @FXML
    private Label subHeading;
    @FXML
    private Label lsbOutcomeLabel;
    @FXML
    private Label dctOutcomeLabel;
    @FXML
    private Button backButton;
    @FXML
    private TextArea outputBox;

    public void setOutputBox(String text){
        outputBox.setText(text);
    }

    public String getOutputBox(){
        return this.outputBox.getText();
    }

    public void setBackButton(Button button){
        this.backButton = button;
    }

    public Button getBackButton(){
        return this.backButton;
    }

    public void setLsbOutcomeLabel(String text){
        lsbOutcomeLabel.setText(text);
    }

    public void setDctOutcomeLabel(String text){
        dctOutcomeLabel.setText(text);
    }

    public Label getLsbOutcomeLabel(){
        return this.lsbOutcomeLabel;
    }

    public Label getDctOutcomeLabel(){
        return this.dctOutcomeLabel;
    }
}
