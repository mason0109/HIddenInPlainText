package Controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

/**
 * This class acts as a Controller Class for 'HidingDataImage'page.fxml and
 * HDImageScene.
 */
public class HideDataImageController {
    @FXML
    private Label HidingDataLabel;
    @FXML
    private Label EnterMessageLabel;
    @FXML
    private Label imageName;
    @FXML
    private TextField MessageTextField;
    @FXML
    private Label UploadCoverLabel;
    @FXML
    private TextField ImageFileBox;
    @FXML
    private Button BrowseButton;
    @FXML
    private Label SelectionLabel;
    @FXML
    private ChoiceBox SelectionBox;
    @FXML
    private Button StartButton;
    @FXML
    private Button BackButton;

    public HideDataImageController() {
    }

    public void setHidingDataLabel(String text) {
        this.HidingDataLabel.setText(text);
    }

    public Label getHidingDataLabel() {
        return HidingDataLabel;
    }

    public void setEnterMessageLabel(String text) {
        this.EnterMessageLabel.setText(text);
    }

    public Label getEnterMessageLabel() {
        return EnterMessageLabel;
    }

    public void setMessageTextField(String text) {
        this.MessageTextField.setText(text);
    }

    public TextField getMessageTextField() {
        return MessageTextField;
    }

    public void setUploadCoverLabel(String text) {
        this.UploadCoverLabel.setText(text);
    }

    public Label getUploadCoverLabel() {
        return UploadCoverLabel;
    }

    public void setImageFileBox(String text) {
        this.ImageFileBox.setText(text);
    }

    public String getImageFileBox(){
        return ImageFileBox.getText();
    }

    public void setBrowseButton(String text){
        this.BrowseButton.setText(text);
    }

    public Button getBrowseButton(){
        return BrowseButton;
    }

    public void setSelectionLabel(String text){
        this.SelectionLabel.setText(text);
    }

    public Label getSelectionLabel(){
        return SelectionLabel;
    }

    public void setSelectionBox(String text){
        this.SelectionBox.getItems().addAll(text);
    }

    public ChoiceBox getSelectionBox(){
        return SelectionBox;
    }

    public void setStartButton(String text){
        this.StartButton.setText(text);
    }

    public Button getStartButton(){
        return StartButton;
    }

    public void setBackButton(String text){
        this.BackButton.setText(text);
    }

    public Button getBackButton(){
        return BackButton;
    }

    public void setImageName(String text){
        this.imageName = imageName;
    }

    public Label getImageName(){
        return imageName;
    }

}
