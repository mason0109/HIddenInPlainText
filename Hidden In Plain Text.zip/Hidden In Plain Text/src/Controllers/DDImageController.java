package Controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

/**
 * This class acts as a Controller Class for 'DetectDataInImage'page.fxml and
 * DDImageScene.
 */
public class DDImageController {
    @FXML
    private Label DetectDataImageLabel;
    @FXML
    private Label UploadLabel;
    @FXML
    private Label SelectionLabel;
    @FXML
    private TextField FileNameTextbox;
    @FXML
    private Button BrowseButton;
    @FXML
    private ChoiceBox SelectionBox;
    @FXML
    private Button StartButton;
    @FXML
    private Button BackButton;

    public DDImageController(){}

    public void setDetectDataImageLabel(String text){
        this.DetectDataImageLabel.setText(text); }

    public Label getDetectDataImageLabel(){
        return DetectDataImageLabel; }

    public void setUploadLabel(String text){
        this.UploadLabel.setText(text); }

    public Label getUploadLabel(){
        return UploadLabel; }

    public void setSelectionLabel(String text){
        this.SelectionLabel.setText(text); }

    public Label getSelectionLabel(){
        return SelectionLabel; }

    public void setFileNameTextbox(String text){
        this.FileNameTextbox.setText(text); }

    public TextField getFileNameTextbox(){
        return FileNameTextbox; }

    public void setBrowseButton(String text){
        this.BrowseButton.setText(text); }

    public Button getBrowseButton(){
        return BrowseButton; }

    public void setSelectionBox(String text, String text2){
        this.SelectionBox.getItems().addAll(text,text2); }

    public ChoiceBox getSelectionBox(){
        return SelectionBox; }

    public void setStartButton(String text){
        this.StartButton.setText(text); }

    public Button getStartButton(){
        return StartButton;
    }

    public void setBackButton(String text){ this.BackButton.setText(text); }

    public Button getBackButton(){ return BackButton; }
}
