package Controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;

/**
 * This class acts as a Controller Class for DetectionOutputText.fxml and
 * DetectionOutputTextScene.
 */
public class DetectionOutputTextController {
    @FXML
    private Label mainLabel;
    @FXML
    private Label subHeading;
    @FXML
    private Label lineShiftOutcomeLabel;
    @FXML
    private Label wordShiftOutcomeLabel;
    @FXML
    private Button backButton;
    @FXML
    private TextArea outputBox;

    public void setOutputBox(String text){
        outputBox.setText(text);
    }

    public String getOutputBox(){
        return this.outputBox.getText();
    }

    public void setBackButton(Button button){
        this.backButton = button;
    }

    public Button getBackButton(){
        return this.backButton;
    }

    public void setLineShiftOutcomeLabel(String text){
        lineShiftOutcomeLabel.setText(text);
    }

    public void setWordShiftOutcomeLabel(String text){ wordShiftOutcomeLabel.setText(text); }

    public Label getLineShiftOutcomeLabel(){
        return this.lineShiftOutcomeLabel;
    }

    public Label getWordShiftOutcomeLabel(){
        return this.wordShiftOutcomeLabel;
    }
}
