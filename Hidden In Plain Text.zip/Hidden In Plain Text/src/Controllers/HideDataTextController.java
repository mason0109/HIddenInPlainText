package Controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

import javax.xml.soap.Text;
import java.awt.*;

/**
 * This class acts as a Controller Class for 'HidingDataInText'page.fxml and
 * HDTextScene.
 */
public class HideDataTextController {
    @FXML
    private Label HidingDataLabel;
    @FXML
    private Label EnterMessageLabel;
    @FXML
    private TextArea MessageTextField;
    @FXML
    private Label EnterCoverLabel;
    @FXML
    private TextArea CoverTextField;
    @FXML
    private Label SelectionLabel;
    @FXML
    private ChoiceBox SelectionBox;
    @FXML
    private Button StartButton;
    @FXML
    private Button BackButton;

    public HideDataTextController(){}

    public void setHidingDataLabel(String text){
        this.HidingDataLabel.setText(text); }

    public Label getHidingDataLabel(){
        return HidingDataLabel; }

    public void setEnterMessageLabel(String text){
        this.EnterMessageLabel.setText(text); }

    public Label getEnterMessageLabel(){
        return EnterMessageLabel; }

    public void setMessageTextField(String text){
        this.MessageTextField.setText(text); }

    public TextArea getMessageTextField(){
        return MessageTextField; }

    public void setEnterCoverLabel(String text){
        this.EnterCoverLabel.setText(text);}

    public Label getEnterCoverLabel(){
        return EnterCoverLabel; }

    public void setCoverTextField(String text){
        this.CoverTextField.setText(text); }

    public TextArea getCoverTextField(){
        return CoverTextField; }

    public void setSelectionLabel(String text){
        this.SelectionLabel.setText(text);}

    public Label getSelectionLabel(){
        return SelectionLabel; }

    public void setSelectionBox(String text, String text2){
        this.SelectionBox.getItems().addAll(text,text2);}

    public ChoiceBox getSelectionBox(){
        return SelectionBox; }

    public void setStartButton(String text){
        this.StartButton.setText(text); }

    public Button getStartButton(){
        return StartButton; }

    public void setBackButton(String text){
        this.BackButton.setText(text); }

    public Button getBackButton(){
        return BackButton; }
}
