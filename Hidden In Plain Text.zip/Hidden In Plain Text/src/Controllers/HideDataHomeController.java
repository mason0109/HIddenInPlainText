package Controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

/**
 * This class acts as a Controller Class for 'HideDataHome.fxml and
 * HideDataHomeScene.
 */
public class HideDataHomeController {
    @FXML
    private Label HideDataLabel;
    @FXML
    private Button InTextButton;
    @FXML
    private Button InImageButton;
    @FXML
    private Button BackButton;

    public HideDataHomeController(){}

    public void setHideDataLabel(String text){
        this.HideDataLabel.setText(text); }

    public Label getHideDataLabel(){
        return HideDataLabel; }

    public void setInTextButton(String text){
        this.InTextButton.setText(text); }

    public Button getInTextButton(){
        return InTextButton; }

    public void setInImageButton(String text){
        this.InImageButton.setText(text);}

    public Button getInImageButton(){
        return InImageButton; }

    public void setBackButton(String text){
        this.BackButton.setText(text); }

    public Button getBackButton(){ return BackButton; }
}
