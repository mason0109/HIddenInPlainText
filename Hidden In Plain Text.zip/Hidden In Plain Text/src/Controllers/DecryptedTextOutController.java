package Controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;

/**
 * This class acts as a Controller Class for DecryptedTextOut.fxml and
 * DecryptedOutputScene.
 */
public class DecryptedTextOutController {
    @FXML
    private Label mainLabel;
    @FXML
    private Button closeButton;
    @FXML
    private Button backButton;
    @FXML
    private TextArea outputBox;

    public DecryptedTextOutController(){};

    public void setMainLabel(String text){
        this.mainLabel.setText(text);
    }

    public void setCloseButton(String text){
        this.backButton.setText(text);
    }

    public void setBackButton(String text){
        this.backButton.setText(text);
    }

    public void setOutputBox(String output){
        this.outputBox.setText(output);
    }

    public Label getMainLabel(){ return this.mainLabel; };

    public Button getCloseButton(){ return this.closeButton; };

    public Button getBackButton(){ return this.backButton; };

    public TextArea getOutputBox(){ return this.outputBox; };
}
