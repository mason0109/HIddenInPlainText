package Controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;

/**
 * This class acts as a Controller Class forMainHomePage.fxml and
 * MainHomeScene.
 */
public class MainHomePageController {
    @FXML
    private AnchorPane root;
    @FXML
    private Label OptionsLabel;
    @FXML
    private Button HideOwnButton;
    @FXML
    private Button DetectButton;
    @FXML
    private Button ExitButton;
    @FXML
    private Button decodeTextButton;
    @FXML
    private Button decodeImageButton;

    public MainHomePageController(){}

    public void setRoot(AnchorPane root){
        this.root = root; }

    public AnchorPane getRoot(){
        return root; }

    public void setOptionsLabel(Label optionsLabel){
        this.OptionsLabel = optionsLabel; }

    public Label getOptionsLabel(){
        return OptionsLabel; }

    public void setHideOwnButton(String text){
        this.HideOwnButton.setText(text); }

    public Button getHideOwnButton(){
        return HideOwnButton; }

    public void setDetectButton(String text){
        this.DetectButton.setText(text); }

    public Button getDetectButton(){
        return DetectButton; }

    public void setExit(String text){
        this.ExitButton.setText(text); }

    public Button getExit(){
        return ExitButton;
    }

    public void setDecodeTextButton(String text){
        this.decodeTextButton.setText(text);
    }

    public Button getDecodeTextButton(){
        return this.decodeTextButton;
    }

    public void setDecodeImageButton(String text){
        this.decodeImageButton.setText(text);
    }

    public Button getDecodeImageButton(){
        return this.decodeImageButton;
    }



}
