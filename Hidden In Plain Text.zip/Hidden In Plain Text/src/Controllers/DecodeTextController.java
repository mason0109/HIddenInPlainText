package Controllers;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

/**
 * This class acts as a Controller Class for 'DecodeText'page.fxml and
 * DecodeTextScene.
 */

public class DecodeTextController {

    @FXML
    private TextArea textToDecodeBox;
    @FXML
    private Button decodeButton;
    @FXML
    private Button backButton;
    @FXML
    private TextArea decodedTextBox;
    @FXML
    private ChoiceBox decodeChoiceBox;

    public DecodeTextController(){}

    public void setTextToDecodeBox(String text){
        this.textToDecodeBox.setText(text);
    }

    public TextArea getTextToDecodeBox(){
        return this.textToDecodeBox;
    }

    public void setDecodedTextBox(String text){
        this.decodedTextBox.setText(text);
    }

    public TextArea getDecodedTextBox(){
        return this.decodedTextBox;
    }

    public void setDecodeButton(String text){
        this.decodeButton.setText(text);
    }

    public void setBackButton(String text) { this.backButton.setText(text); }

    public Button getBackButton() { return this.backButton; }

    public Button getDecodeButton(){
        return this.decodeButton;
    }

    public void setDecodeChoiceBox(String text, String text2){
        this.decodeChoiceBox.getItems().addAll(text, text2);
    }

    public ChoiceBox getDecodeChoiceBox(){ return this.decodeChoiceBox; }

}
