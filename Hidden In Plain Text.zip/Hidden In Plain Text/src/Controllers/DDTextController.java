package Controllers;

import javafx.fxml.FXML;
import javafx.scene.control.*;

/**
 * This class acts as a Contoller Class for 'DetectDataInText'page.fxml and
 * DDTextScene.
 */
public class DDTextController {
    @FXML
    private Label DetectingTextLabel;
    @FXML
    private Label EnterTextLabel;
    @FXML
    private TextArea UserTextField;
    @FXML
    private Label SelectionLabel;
    @FXML
    private Button StartButton;
    @FXML
    private Button BackButton;

    public DDTextController(){}

    public void setDetectingTextLabel(String text){
        this.DetectingTextLabel.setText(text); }

    public Label getDetectingTextLabel(){
        return DetectingTextLabel; }

    public void setEnterTextLabel(String text){
        this.EnterTextLabel.setText(text); }

    public Label getEnterTextLabel(){
        return EnterTextLabel; }

    public void setUserTextField(String text){
        this.UserTextField.setText(text); }

    public TextArea getUserTextField(){
        return UserTextField; }

    public void setSelectionLabel(String text){
        this.SelectionLabel.setText(text); }

    public Label getSelectionLabel(){
        return SelectionLabel; }

    public void setStartButton(String text){
        this.StartButton.setText(text); }

    public Button getStartButton(){
        return StartButton; }

    public void setBackButton(String text){
        this.BackButton.setText(text); }

    public Button getBackButton(){ return BackButton; }
}
