package Controllers;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

/**
 * This class acts as a Controller Class for 'DetectData'home.fxml and
 * DDHomeScene.
 */

public class DDHomeController {
    @FXML
    private Button TextOptionButton;
    @FXML
    private Button ImageOptionButton;
    @FXML
    private Button BackButton;
    @FXML
    private Label DetectDataLabel;

    public DDHomeController(){}

    public void setTextOptionButton(String textOptionButton) {
        this.TextOptionButton.setText(textOptionButton);
    }

    public Button getTextOptionButton(){
        return TextOptionButton;
    }

    public void setImageOptionButton(String text){
        this.ImageOptionButton.setText(text);
    }

    public Button getImageOptionButton(){
        return ImageOptionButton;
    }

    public void setBackButton(String text){
        this.BackButton.setText(text);
    }

    public Button getBackButton(){
        return BackButton;
    }

    public void setDetectDataLabel(String text) {
        this.DetectDataLabel.setText(text); }
}
